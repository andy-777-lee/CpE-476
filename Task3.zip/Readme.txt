Task 3: Wheel Calibration (fix systematic errors)- The goal of this task will be to move your robot using built-in commands for a distance of 2 meters. 
Determine the trim values of the motor such that the robot travels in a straight line.

Our general motor spec is below. 
Gear ratio 120:1
150rpm (4.5v  200)
Wheel diameter is 70mm ( circumference=7*3.14 = 21.98cm ) 
From the specs of our rover, to go to the 2 meters, the wheels have to spin 9 times.
Using those specs, we set valid value to go 2 meters. Additionally, one our wheels waved a lot. This required addition time and testing to troubleshooting. 
