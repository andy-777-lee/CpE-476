PS4 Controller for RomiPi

Below is my experience with
Ubuntu 18.04 VM on my grey MacBook

Install Dual Shock 4 Driver
* sudo apt-get install python-pip
* sudo pip install ds4drv
* connect controller via usb
* sudo ds4drv —hiraw
** Open instructions here if you have trouble: https://github.com/chrippa/ds4drv

Test with GUI App (optional, but suggested)
* sudo apt-get install jstest-gtk
* sudo jstest-gtk

PS4 controller working with USB


