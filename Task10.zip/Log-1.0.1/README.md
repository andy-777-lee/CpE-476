# Arduino logger lib

## Description
Simple but useful macroses for logging. Allow use printf() with Serial for logging.

## Supported Boards
- All

## License

### MIT
This work is licensed under the MIT License.
To view a copy of this license, visit https://tldrlegal.com/license/mit-license
