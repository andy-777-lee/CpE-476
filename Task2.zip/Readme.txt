Task 2: Motor and Encoder Testing - In this task, the team will perform basic tests for the motor (proper forward, backward, right and left motion), and encoder operations.

For the Task 2, we make use of Romi32U4 Arduino library to assist us interface with the motors.
For the for the Encoder operation, we used Encoder example. After several experiments we realized that right side of motor needed to be set more higher speed in order to move straight line. The speeds are (100,103).
The other motions ( backward, left, right motion) are the same way with straight line test.
